/* Objeto normal
const book = {
    bookTitle: 'Oscar Wilde - The Picture of Dorian Gray',
    bookAuthor: 'Oscar Wilde',
    bookPages: 254,
    bookChapters: {
        chap1: 'The Portrait',
        chap2: 'The Dorian Gray',
        chap3: 'The Fall'
    },
    printBook: function() {
        console.log('printing..');
    }
}


book.printBook();
*/



//FACTORY FUNCTION

/*
function createBook (bookTitle, bookAuthor, bookPages, bookChapters) {
    const book = {
        bookTitle: bookTitle,
        bookAuthor: bookAuthor,
        bookPages: bookPages,
        printBook: function() {
        console.log('printing..');
        }
    }
    return book;
}

const book1 = createBook('Oscar Wilde - The Picture of Dorian Gray', 'Oscar Wilde', 254);

//posso adicionar novas propriedades ao objeto pois ele é dinâmico após ser criado;
book1.color = 'white';

console.log(book1); 

*/

/*
//Constructor Function
//muito mais facil do que a factory function
function CreateBook (bookTitle, bookAuthor, bookPages) {
    this.bookTitle = bookTitle; //o this retorna a função automaticamente
    this.bookAuthor = bookAuthor;
    this.bookPages = bookPages;
}

const book1 = new CreateBook('Oscar Wilde - The Picture of Dorian Gray', 'Oscar Wilde', 254);
console.log(book1);
*/

/* Arrays e valores adicionados
const num = [7, 8, 9];
num.push(10); //adiciona o valor 10 ao array no final
num.unshift(1,2,3); //adiciona o valor 6 ao array no começo
num.splice(3, 0, 4, 5, 6); //adiciona os valores 4,5,6 na posição 3 do array
console.log(num);
*/ 


/*
const movies = [
    {id: 1, movieName: 'The Shawshank Redemption'},
    {id: 2, movieName: 'The Godfather'},
    {id: 3, movieName: 'The Dark Knight'}
]
console.log(movies.find(function(movie) {
    return movie.movieName === 'The Godfather';
}));

//Mesma coisa de cima, mas com arrow function > return implícito 
console.log(movies.find(movie => movie.movieName === 'The Godfather'));
*/


//removendo valores de um array
const num = [5, 6, 7, 8];
const final = num.pop(); //remove o ultimo valor do array e retorna ele
const inicio = num.shift(); //remove o primeiro valor do array e retorna ele
const meio = num.splice(2, 1); //remove o valor da posição 1 do array e retorna ele

console.log(num);
console.log(meio);
console.log(final);
console.log(inicio);

//concatenar arrays
const array1 = [1, 2, 3];
const array2 = ['a', 'b', 'c'];
all = array1.concat(array2);
half = all.slice(3, 5); //cria um novo array a partir do array all, do indice 2 ao 5 (5 não incluso)

console.log(all);  

//join array
let clientes = ['Maria', 'João', 'Pedro'];
console.log(clientes);

let clientesJoin = clientes.join(', '); //transforma o array em string, separando os valores pelo que for colocado no join
console.log(clientesJoin);


/*reverter array
let clients = ['Maria', 'João', 'Pedro'];
clients.sort(); //ordena o array em ordem alfabética
console.log(clients);
clients.reverse(); //inverte a ordem do array
console.log(clients);
*/

/*verificando elementos em um array
const tempLondon = [18, 13, 8, 2] ;

const tempPositive = tempLondon.every(function(value){
    return value >= 0;
})
console.log(tempPositive);
*/



/*metodo filter filtra os valores do array de acordo com a condição passada
const tempLondon = [18, -13, 8, 2] ;

const tempPositive = tempLondon.filter(function(value){
    return value >= 0;
})
console.log(tempPositive);
//mesma coisa de cima, mas com arrow function > return implícito
retorna o value se for maior ou igual a 0
const tempPositive = tempLondon.filter(value => value >= 0);
console.log(tempPositive);
*/  


