
/*
// Function Declaration
function movie() {
    console.log(Matrix);
}

//Function Expression
const car = function() {
    console.log('BMW');
};
console.log(car);
*/


/*
function price() { //argumentos
    let total = 0;
    for (let value of arguments) { //parametros
        total += value;
    return total;
    }
}

console.log(price(10, 20, 30, 40));
*/

//associar valores default aos argumentos
/*
function carLoan(loan, rate = 2.9, years = 5) {
    return loan * rate / 100 * years;
}

console.log(carLoan(20000, 2.5, 5));
*/