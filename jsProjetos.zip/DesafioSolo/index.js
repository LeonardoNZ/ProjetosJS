let tasks = [];

function init() {
    tasks = [];
    document.getElementById('errorMessage').innerHTML = '';
    document.getElementById('taskInput').value = '';
    document.getElementById('taskList').value = '';
}

function addTask(){
    taskInput.value = taskInput.value.trim();
    if (taskInput.value === '') {
        alert('a tarefa deve estar preenchida');
        return;
    }
    const taskInput = document.getElementById('taskInput');
    console.log("Adding task:", taskInput.value);

    tasks.push(taskInput.value);
    taskInput.value = '';
    document.getElementById('taskList').innerHTML = tasks;
}
 