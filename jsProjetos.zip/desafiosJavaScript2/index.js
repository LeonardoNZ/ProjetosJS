let productValue = Number(prompt("Enter the product value:"));


if (productValue >= 20) {
    document.getElementById("result").innerText = "Approved: " + productValue + " is >= 20";
} else {
    document.getElementById("result").innerText = "Dennied: " + productValue + " is < 20";
}
   