//inicia
let computerNumber;
let userNumbers = [];
let attempts = 0;
let maxAttempts = 10;

//função que reinicia o jogo
function newGame() {
    window.location.reload();
}



//função que inicia o jogo e gera um número aleatório
function init() {
    computerNumber = Math.floor(Math.random() * 100) + 1;
    console.log(computerNumber);
}

// função que compara os números e fornece feedback caso o numero seja maior ou menor do é permitido
function compareNumbers() {
    const userNumber = Number(document.getElementById('inputBox').value)
    if (userNumber < 1 || userNumber > 100) {
        alert('Please enter a number between 1 and 100.');
        document.getElementById('inputBox').value = '';
        return;
    }
    userNumbers.push(' ' + userNumber);
    document.getElementById('guesses').innerHTML = userNumbers;



//logica de tentativas
        if (attempts < maxAttempts) {
            if (userNumber < computerNumber) {
                document.getElementById('textOutput').innerHTML = 'Your guess is too low!';
                document.getElementById('inputBox').value = '';
                attempts++;
                document.getElementById('attempts').innerHTML = attempts;


            } else if (userNumber > computerNumber) {
                document.getElementById('textOutput').innerHTML = 'Your guess is too high!';
                document.getElementById('inputBox').value = '';
                attempts++;
                document.getElementById('attempts').innerHTML = attempts;

            } else {
                document.getElementById('textOutput').innerHTML = 'Congratulations! You guessed the number!';
                attempts++;
                document.getElementById('attempts').innerHTML = attempts;
                document.getElementById('inputBox').setAttribute('readonly', 'readonly');
            }

        }
        else {
            document.getElementById('textOutput').innerHTML = 'Game Over! The number was ' + computerNumber + '.';
            document.getElementById('inputBox').setAttribute('readonly', 'readonly');
        }

    }



