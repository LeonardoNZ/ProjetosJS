console.log("Olá, mundo!");


let firstName= "LeoNZ";
let lastName= "Santos";
console.log("Bem-vindo, " + firstName + " " + lastName + "!");

let pen= {
    itemName: 'Pen',
    itemColor: 'Blue',
    itemPrice: 3,
    itemAvailable: true
}

console.log(pen);


function percentage10(price) {
    return price - (price * 10/100);
}

console.log("O preço com 10% de desconto é: " + percentage10(20));

// operadores ternarios;
// let driver = 90;
// let speed = 110 ? 'Above' : 'Below';
// console.log(speed);

/*
Operadores logicos

let temIdade = true;
let temTituloEleitos = false;

let podevotar = temIdade && temTituloEleitos;
console.log(podevotar);

let podevotar = temIdade || temTituloEleitos;
console.log(podevotar);

*/


let velocidadeMax = 110;
let velocidadeMotorista = 30;

if (velocidadeMotorista > velocidadeMax) {
    console.log("Multado! Você excedeu o limite de velocidade de " + velocidadeMax + " km/h.");
}else if(velocidadeMotorista < (60/100 * velocidadeMax)){
    console.log("Você está abaixo do limite de velocidade.");
}else 
    console.log("Velocidade dentro do limite. Boa viagem!");


/* SWITCH CASE
let airpot = 'SEA'

switch (airpot) {
    case 'MCO':
        console.log("Orlando International Airport");
        break;
    case 'JFK':
        console.log("John F. Kennedy International Airport");
        break;
    case 'SEA':
        console.log("Seattle-Tacoma International Airport");
        break;
    default:
        console.log("Airport not recognized");
}
*/


/* LOOP FOR -> variavel é internamente criada e incrementada
for (let i = 1; i <= 10; i++) {
    console.log("Contagem: " + i);
}
*/ 

/* LOOP WHILE variavel é criada externamente e incrementada
let i = 1;
while (i <= 10) {
    console.log("Contagem: " + i);
    i++;
}
*/ 

/* LOOP DO WHILE -> executa pelo menos uma vez pois verifica depois
let i = 1;
do {
    console.log("Contagem: " + i);
    i++;
}   while (i <= 10);
*/

/* for in
const myCar{
    model: 'Mustang',
    year: 1969,
    }
for (let i in myCar) {
    console.log(i + ": " + myCar[i]);
}
*/

/* for of
const cars = ['BMW', 'Volvo', 'Mini'];

for (let i of cars) {
    console.log(i  );
}
*/